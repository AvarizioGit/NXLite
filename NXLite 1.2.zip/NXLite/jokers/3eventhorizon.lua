
SMODS.Joker{ --Event Horizon
    key = "3eventhorizon",
    config = {
        extra = {
            lvlvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Event Horizon',
        ['text'] = {
            [1] = '{C:attention}Levels up{} your {C:attention}most played{}',
            [2] = 'hand by {C:attention}#1#{} when sold',
            [3] = '{C:inactive}(Doubles at end of round){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.lvlvar}}
    end,
    
    calculate = function(self, card, context)
        if context.selling_self  then
            local temp_played = 0
            local temp_order = math.huge
            local target_hand
            for hand, value in pairs(G.GAME.hands) do 
                if value.played > temp_played and value.visible then
                    temp_played = value.played
                    temp_order = value.order
                    target_hand = hand
                elseif value.played == temp_played and value.visible then
                    if value.order < temp_order then
                        temp_order = value.order
                        target_hand = hand
                    end
                end
            end
            
            level_up_hand(card, target_hand, true, card.ability.extra.lvlvar)
            return {
                message = localize('k_level_up_ex')
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.lvlvar = (card.ability.extra.lvlvar) + card.ability.extra.lvlvar
                    return true
                end
            }
        end
    end
}