
SMODS.Joker{ --First Aid Kit
    key = "3firstaidkit",
    config = {
        extra = {
            triagevar = 3,
            blindreqvar = 25,
            dollars0 = 25,
            dollars = 25
        }
    },
    loc_txt = {
        ['name'] = 'First Aid Kit',
        ['text'] = {
            [1] = '{C:blue}Prevents death{} if score is at least',
            [2] = '{C:attention}#2#%{} of the blind then gives {C:money}$25{}',
            [3] = 'and a {C:attention}Juggle Tag{} when triggered',
            [4] = '{C:inactive}({}{C:attention}#1#{}{C:inactive}/3 uses, requirements increase each trigger){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.triagevar, card.ability.extra.blindreqvar}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over and context.main_eval  and not context.blueprint then
            if (to_big((card.ability.extra.triagevar or 0)) > to_big(1) and to_big(G.GAME.chips / G.GAME.blind.chips) >= to_big(NaN)) then
                return {
                    saved = true,
                    message = localize('k_saved_ex'),
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 25
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(25), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY,
                        extra = {
                            func = function()
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local tag = Tag("tag_juggle")
                                        if tag.name == "Orbital Tag" then
                                            local _poker_hands = {}
                                            for k, v in pairs(G.GAME.hands) do
                                                if v.visible then
                                                    _poker_hands[#_poker_hands + 1] = k
                                                end
                                            end
                                            tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                        end
                                        tag:set_ability()
                                        add_tag(tag)
                                        play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                        return true
                                    end
                                }))
                                return true
                            end,
                            message = "Created Tag!",
                            colour = G.C.GREEN,
                            extra = {
                                func = function()
                                    card.ability.extra.triagevar = math.max(0, (card.ability.extra.triagevar) - 1)
                                    return true
                                end,
                                colour = G.C.RED,
                                extra = {
                                    func = function()
                                        card.ability.extra.blindreqvar = (card.ability.extra.blindreqvar) + 25
                                        return true
                                    end,
                                    colour = G.C.GREEN
                                }
                            }
                        }
                    }
                }
            elseif (to_big((card.ability.extra.triagevar or 0)) <= to_big(1) and to_big(G.GAME.chips / G.GAME.blind.chips) >= to_big(NaN)) then
                return {
                    saved = true,
                    message = localize('k_saved_ex'),
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 25
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(25), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY,
                        extra = {
                            func = function()
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local tag = Tag("tag_juggle")
                                        if tag.name == "Orbital Tag" then
                                            local _poker_hands = {}
                                            for k, v in pairs(G.GAME.hands) do
                                                if v.visible then
                                                    _poker_hands[#_poker_hands + 1] = k
                                                end
                                            end
                                            tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                        end
                                        tag:set_ability()
                                        add_tag(tag)
                                        play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                        return true
                                    end
                                }))
                                return true
                            end,
                            message = "Created Tag!",
                            colour = G.C.GREEN,
                            extra = {
                                func = function()
                                    local target_joker = card
                                    
                                    if target_joker then
                                        target_joker.getting_sliced = true
                                        G.E_MANAGER:add_event(Event({
                                            func = function()
                                                target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                                return true
                                            end
                                        }))
                                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                                    end
                                    return true
                                end,
                                colour = G.C.RED
                            }
                        }
                    }
                }
            end
        end
    end
}