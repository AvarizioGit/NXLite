
SMODS.Joker{ --Thalia Symphonia
    key = "4thalia",
    config = {
        extra = {
            chipmultvar = 1,
            scalevar = 0.25
        }
    },
    loc_txt = {
        ['name'] = 'Thalia Symphonia',
        ['text'] = {
            [1] = '{C:attention}Reduces{} card requirement for making',
            [2] = '{C:attention}Straights{} and {C:attention}Flushes{} by {C:attention}1',
            [3] = '{}Gains {X:tarot,C:white}X#2#{} Chips and Mult if',
            [4] = 'hand contains a {C:attention}Straight Flush{}',
            [5] = '{C:inactive}(Currently{} {X:tarot,C:white}X#1#{} {C:inactive}Chips and Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 18
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    soul_pos = {
        x = 4,
        y = 21
    },
    in_pool = function(self, args)
        return (
            not args
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chipmultvar, card.ability.extra.scalevar}}
    end,
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if next(context.poker_hands["Straight Flush"]) then
                return {
                    func = function()
                        card.ability.extra.chipmultvar = (card.ability.extra.chipmultvar) + card.ability.extra.scalevar
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.chipmultvar,
                extra = {
                    x_chips = card.ability.extra.chipmultvar,
                    colour = G.C.DARK_EDITION
                }
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        -- Flush/Straight requirements reduced by 1
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        -- Flush/Straight requirements restored
    end
}


local smods_four_fingers_ref = SMODS.four_fingers
function SMODS.four_fingers()
    if next(SMODS.find_card("j_nx_4thalia")) then
        return 4
    end
    return smods_four_fingers_ref()
end