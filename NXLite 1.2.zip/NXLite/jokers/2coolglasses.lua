
SMODS.Joker{ --Cool Glasses
    key = "2coolglasses",
    config = {
        extra = {
            multvar = 1,
            firstvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Cool Glasses',
        ['text'] = {
            [1] = 'If a {C:attention}Blind{} is beaten in {C:attention}1{} hand',
            [2] = 'This Joker gains {X:red,C:white}X0.25{} Mult',
            [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 21
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar, card.ability.extra.firstvar}}
    end,
    
    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
            if to_big((card.ability.extra.firstvar or 0)) == to_big(1) then
                return {
                    func = function()
                        card.ability.extra.multvar = (card.ability.extra.multvar) + 0.25
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.firstvar = 0
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.hands_played == 0 then
                card.ability.extra.firstvar = 1
                return {
                    Xmult = card.ability.extra.multvar
                }
            elseif not (G.GAME.current_round.hands_played == 0) then
                card.ability.extra.firstvar = 0
                return {
                    Xmult = card.ability.extra.multvar
                }
            end
        end
    end
}