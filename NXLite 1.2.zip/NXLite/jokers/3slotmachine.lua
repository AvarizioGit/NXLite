
SMODS.Joker{ --Slot Machine
    key = "3slotmachine",
    config = {
        extra = {
            numvar1 = 0,
            numvar2 = 0,
            numvar3 = 0,
            scale0 = 1,
            rotation0 = 1,
            dollars0 = 30,
            scale = 1,
            rotation = 1,
            scale2 = 1,
            rotation2 = 1,
            dollars = 45,
            scale3 = 1,
            rotation3 = 1,
            scale4 = 1,
            rotation4 = 1,
            scale5 = 1,
            rotation5 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Slot Machine',
        ['text'] = {
            [1] = '{C:attention}Spins{} the slot machine when hand is played',
            [2] = 'Gain rewards when {C:attention}3{} of the same number shows',
            [3] = '{C:inactive}({} {C:attention}#1# #2# #3#{} {C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 23
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.numvar1, card.ability.extra.numvar2, card.ability.extra.numvar3}}
    end,
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            local target_card = context.other_card
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("nx_slotpull")
                    
                    return true
                end,
            }))
            return {
                func = function()
                    card.ability.extra.numvar1 = pseudorandom('RANGE:5|9', 5, 9)
                    return true
                end,
                extra = {
                    func = function()
                        card.ability.extra.numvar2 = pseudorandom('RANGE:5|9', 5, 9)
                        return true
                    end,
                    colour = G.C.BLUE,
                    extra = {
                        func = function()
                            card.ability.extra.numvar3 = pseudorandom('RANGE:5|9', 5, 9)
                            return true
                        end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                                card:juice_up(1, 1)
                                return true
                            end,
                            colour = G.C.WHITE
                        }
                    }
                }
            }
        end
        if context.after and context.cardarea == G.jokers  then
            if (to_big((card.ability.extra.numvar1 or 0)) == to_big(6) and to_big((card.ability.extra.numvar2 or 0)) == to_big(6) and to_big((card.ability.extra.numvar3 or 0)) == to_big(6)) then
                local target_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("nx_jackpot")
                        
                        return true
                    end,
                }))
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 30
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(30), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        func = function()
                            card:juice_up(1, 1)
                            return true
                        end,
                        colour = G.C.WHITE
                    }
                }
            elseif (to_big((card.ability.extra.numvar1 or 0)) == to_big(7) and to_big((card.ability.extra.numvar2 or 0)) == to_big(7) and to_big((card.ability.extra.numvar3 or 0)) == to_big(7)) then
                local target_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("nx_jackpot")
                        
                        return true
                    end,
                }))
                return {
                    func = function()
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                local tag = Tag(selected_tag)
                                if tag.name == "Orbital Tag" then
                                    local _poker_hands = {}
                                    for k, v in pairs(G.GAME.hands) do
                                        if v.visible then
                                            _poker_hands[#_poker_hands + 1] = k
                                        end
                                    end
                                    tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                end
                                tag:set_ability()
                                add_tag(tag)
                                play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                return true
                            end
                        }))
                        return true
                    end,
                    message = "Created Tag!",
                    extra = {
                        func = function()
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                    local tag = Tag(selected_tag)
                                    if tag.name == "Orbital Tag" then
                                        local _poker_hands = {}
                                        for k, v in pairs(G.GAME.hands) do
                                            if v.visible then
                                                _poker_hands[#_poker_hands + 1] = k
                                            end
                                        end
                                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                    end
                                    tag:set_ability()
                                    add_tag(tag)
                                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                    return true
                                end
                            }))
                            return true
                        end,
                        message = "Created Tag!",
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                        local tag = Tag(selected_tag)
                                        if tag.name == "Orbital Tag" then
                                            local _poker_hands = {}
                                            for k, v in pairs(G.GAME.hands) do
                                                if v.visible then
                                                    _poker_hands[#_poker_hands + 1] = k
                                                end
                                            end
                                            tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                        end
                                        tag:set_ability()
                                        add_tag(tag)
                                        play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                        return true
                                    end
                                }))
                                return true
                            end,
                            message = "Created Tag!",
                            colour = G.C.GREEN,
                            extra = {
                                func = function()
                                    card:juice_up(1, 1)
                                    return true
                                end,
                                colour = G.C.WHITE
                            }
                        }
                    }
                }
            elseif (to_big((card.ability.extra.numvar1 or 0)) == to_big(8) and to_big((card.ability.extra.numvar2 or 0)) == to_big(8) and to_big((card.ability.extra.numvar3 or 0)) == to_big(8)) then
                local target_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("nx_jackpot")
                        
                        return true
                    end,
                }))
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 45
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(45), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        func = function()
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                    local tag = Tag(selected_tag)
                                    if tag.name == "Orbital Tag" then
                                        local _poker_hands = {}
                                        for k, v in pairs(G.GAME.hands) do
                                            if v.visible then
                                                _poker_hands[#_poker_hands + 1] = k
                                            end
                                        end
                                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                    end
                                    tag:set_ability()
                                    add_tag(tag)
                                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                    return true
                                end
                            }))
                            return true
                        end,
                        message = "Created Tag!",
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                        local tag = Tag(selected_tag)
                                        if tag.name == "Orbital Tag" then
                                            local _poker_hands = {}
                                            for k, v in pairs(G.GAME.hands) do
                                                if v.visible then
                                                    _poker_hands[#_poker_hands + 1] = k
                                                end
                                            end
                                            tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                        end
                                        tag:set_ability()
                                        add_tag(tag)
                                        play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                        return true
                                    end
                                }))
                                return true
                            end,
                            message = "Created Tag!",
                            colour = G.C.GREEN,
                            extra = {
                                func = function()
                                    G.E_MANAGER:add_event(Event({
                                        func = function()
                                            local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                            local tag = Tag(selected_tag)
                                            if tag.name == "Orbital Tag" then
                                                local _poker_hands = {}
                                                for k, v in pairs(G.GAME.hands) do
                                                    if v.visible then
                                                        _poker_hands[#_poker_hands + 1] = k
                                                    end
                                                end
                                                tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                            end
                                            tag:set_ability()
                                            add_tag(tag)
                                            play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                            return true
                                        end
                                    }))
                                    return true
                                end,
                                message = "Created Tag!",
                                colour = G.C.GREEN,
                                extra = {
                                    func = function()
                                        G.E_MANAGER:add_event(Event({
                                            func = function()
                                                local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                                local tag = Tag(selected_tag)
                                                if tag.name == "Orbital Tag" then
                                                    local _poker_hands = {}
                                                    for k, v in pairs(G.GAME.hands) do
                                                        if v.visible then
                                                            _poker_hands[#_poker_hands + 1] = k
                                                        end
                                                    end
                                                    tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                                end
                                                tag:set_ability()
                                                add_tag(tag)
                                                play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                                return true
                                            end
                                        }))
                                        return true
                                    end,
                                    message = "Created Tag!",
                                    colour = G.C.GREEN,
                                    extra = {
                                        func = function()
                                            G.E_MANAGER:add_event(Event({
                                                func = function()
                                                    local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                                    local tag = Tag(selected_tag)
                                                    if tag.name == "Orbital Tag" then
                                                        local _poker_hands = {}
                                                        for k, v in pairs(G.GAME.hands) do
                                                            if v.visible then
                                                                _poker_hands[#_poker_hands + 1] = k
                                                            end
                                                        end
                                                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                                    end
                                                    tag:set_ability()
                                                    add_tag(tag)
                                                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                                    return true
                                                end
                                            }))
                                            return true
                                        end,
                                        message = "Created Tag!",
                                        colour = G.C.GREEN,
                                        extra = {
                                            func = function()
                                                
                                                local created_joker = true
                                                G.E_MANAGER:add_event(Event({
                                                    func = function()
                                                        local joker_card = SMODS.add_card({ set = 'Joker' })
                                                        if joker_card then
                                                            joker_card:set_edition("e_negative", true)
                                                            
                                                        end
                                                        
                                                        return true
                                                    end
                                                }))
                                                
                                                if created_joker then
                                                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                                                end
                                                return true
                                            end,
                                            colour = G.C.BLUE,
                                            extra = {
                                                func = function()
                                                    
                                                    local created_joker = true
                                                    G.E_MANAGER:add_event(Event({
                                                        func = function()
                                                            local joker_card = SMODS.add_card({ set = 'Joker' })
                                                            if joker_card then
                                                                joker_card:set_edition("e_negative", true)
                                                                
                                                            end
                                                            
                                                            return true
                                                        end
                                                    }))
                                                    
                                                    if created_joker then
                                                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                                                    end
                                                    return true
                                                end,
                                                colour = G.C.BLUE,
                                                extra = {
                                                    func = function()
                                                        
                                                        for i = 1, 4 do
                                                            G.E_MANAGER:add_event(Event({
                                                                trigger = 'after',
                                                                delay = 0.4,
                                                                func = function()
                                                                    if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
                                                                        G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                                                                    end
                                                                    
                                                                    play_sound('timpani')
                                                                    local sets = {'Tarot', 'Planet', 'Spectral'}
                                                                    local random_set = pseudorandom_element(sets, 'random_consumable_set')
                                                                    SMODS.add_card({ set = random_set, edition = 'e_negative', })                            
                                                                    card:juice_up(0.3, 0.5)
                                                                    return true
                                                                end
                                                            }))
                                                        end
                                                        delay(0.6)
                                                        
                                                        if created_consumable then
                                                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_consumable'), colour = G.C.PURPLE})
                                                        end
                                                        return true
                                                    end,
                                                    colour = G.C.PURPLE,
                                                    extra = {
                                                        func = function()
                                                            card:juice_up(1, 1)
                                                            return true
                                                        end,
                                                        colour = G.C.WHITE
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            elseif (to_big((card.ability.extra.numvar1 or 0)) == to_big(5) and to_big((card.ability.extra.numvar2 or 0)) == to_big(5) and to_big((card.ability.extra.numvar3 or 0)) == to_big(5)) then
                local target_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("nx_jackpot")
                        
                        return true
                    end,
                }))
                return {
                    func = function()
                        
                        local created_joker = true
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local joker_card = SMODS.add_card({ set = 'Joker' })
                                if joker_card then
                                    joker_card:set_edition("e_negative", true)
                                    
                                end
                                
                                return true
                            end
                        }))
                        
                        if created_joker then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            card:juice_up(1, 1)
                            return true
                        end,
                        colour = G.C.WHITE
                    }
                }
            elseif (to_big((card.ability.extra.numvar1 or 0)) == to_big(9) and to_big((card.ability.extra.numvar2 or 0)) == to_big(9) and to_big((card.ability.extra.numvar3 or 0)) == to_big(9)) then
                local target_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("nx_jackpot")
                        
                        return true
                    end,
                }))
                return {
                    func = function()
                        
                        for i = 1, 3 do
                            G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
                                        G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                                    end
                                    
                                    play_sound('timpani')
                                    local sets = {'Tarot', 'Planet', 'Spectral'}
                                    local random_set = pseudorandom_element(sets, 'random_consumable_set')
                                    SMODS.add_card({ set = random_set, edition = 'e_negative', })                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                end
                            }))
                        end
                        delay(0.6)
                        
                        if created_consumable then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_consumable'), colour = G.C.PURPLE})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            card:juice_up(1, 1)
                            return true
                        end,
                        colour = G.C.WHITE
                    }
                }
            end
        end
    end
}