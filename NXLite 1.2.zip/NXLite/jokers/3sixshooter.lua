
SMODS.Joker{ --Six-Shooter
    key = "3sixshooter",
    config = {
        extra = {
            multvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Six-Shooter',
        ['text'] = {
            [1] = '{C:attention}6s{} held in hand gives {X:red,C:white}X0.6{} Mult to',
            [2] = 'this Joker and {C:attention}resets{} each hand',
            [3] = '{C:inactive}(Previously{} {X:red,C:white}X#1#{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 16
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card:get_id() == 6 then
                return {
                    func = function()
                        card.ability.extra.multvar = (card.ability.extra.multvar) + 0.6
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multvar
            }
        end
        if context.before and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.multvar = 1
                    return true
                end
            }
        end
    end
}