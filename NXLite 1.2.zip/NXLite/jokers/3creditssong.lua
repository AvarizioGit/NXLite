
SMODS.Joker{ --Credits Song For My Death But Im The Joker
    key = "3creditssong",
    config = {
        extra = {
            deathvar = 'Inactive',
            trigvar = 1,
            dollars0 = 0,
            xmult0 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Credits Song For My Death But Im The Joker',
        ['text'] = {
            [1] = '{C:attention}Prevents death{} once and sets {C:gold}money{} to {C:attention}0{}',
            [2] = 'then gives {X:red,C:white}X5{} Mult when hand is played',
            [3] = '{C:inactive}(Currently #1#){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.deathvar, card.ability.extra.trigvar}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over and context.main_eval  then
            if card.ability.extra.deathvar == 'Inactive' then
                card.ability.extra.deathvar = 'Active'
                return {
                    saved = true,
                    message = localize('k_saved_ex'),
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = 0
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to $"..tostring(0), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY
                    }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if card.ability.extra.deathvar == 'Active' then
                return {
                    Xmult = 5
                }
            end
        end
    end
}