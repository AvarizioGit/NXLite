
SMODS.Joker{ --Synthetica
    key = "3synthetica",
    config = {
        extra = {
            chipvar = 20,
            multvar = 12,
            chipincvar = 20,
            multincvar = 12
        }
    },
    loc_txt = {
        ['name'] = 'Synthetica',
        ['text'] = {
            [1] = 'Played {C:attention}2s{} gives {C:blue}+#1#{} Chips',
            [2] = 'and {C:red}+#2#{} Mult when {C:attention}scored{}',
            [3] = 'Increases by {C:blue}+#3#{} Chips and',
            [4] = '{C:red}+#4#{} Mult for each {C:attention}2{} scored',
            [5] = '{C:inactive}(Resets each hand){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 17
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chipvar, card.ability.extra.multvar, card.ability.extra.chipincvar, card.ability.extra.multincvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 2 then
                local chipvar_value = card.ability.extra.chipvar
                local multvar_value = card.ability.extra.multvar
                card.ability.extra.chipvar = (card.ability.extra.chipvar) + card.ability.extra.chipincvar
                card.ability.extra.multvar = (card.ability.extra.multvar) + card.ability.extra.multincvar
                return {
                    chips = chipvar_value,
                    extra = {
                        mult = multvar_value
                    }
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.chipvar = card.ability.extra.chipincvar
                    return true
                end,
                extra = {
                    func = function()
                        card.ability.extra.multvar = card.ability.extra.multincvar
                        return true
                    end,
                    colour = G.C.BLUE
                }
            }
        end
    end
}