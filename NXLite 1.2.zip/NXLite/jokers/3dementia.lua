
SMODS.Joker{ --Dementia
    key = "3dementia",
    config = {
        extra = {
            jokercount = 1,
            jokervar = 0.1
        }
    },
    loc_txt = {
        ['name'] = 'Dementia',
        ['text'] = {
            [1] = '{C:attention}Flips{} all Jokers when {C:attention}Blind{} is selected',
            [2] = 'Non-{C:attention}first/last{} cards gives {X:red,C:white}X#2#{} Mult when scored',
            [3] = 'Increases by {X:red,C:white}X#1#{} for each owned Joker'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.jokervar, card.ability.extra.jokercount + (#(G.jokers and (G.jokers and G.jokers.cards or {}) or {})) * card.ability.extra.jokervar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (not (context.other_card == context.scoring_hand[1]) and not (context.other_card == context.scoring_hand[#context.scoring_hand])) then
                return {
                    Xmult = card.ability.extra.jokercount + (#(G.jokers and G.jokers.cards or {})) * card.ability.extra.jokervar
                }
            end
        end
        if context.setting_blind and not context.blueprint then
            if #G.jokers.cards > 0 then
                for _, joker in ipairs(G.jokers.cards) do
                    joker:flip()
                end
            end
            return {
                message = "Flip!"
            }
        end
    end
}