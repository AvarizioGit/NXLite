
SMODS.Joker{ --Kanta Miyamoto
    key = "4kantamiyamoto",
    config = {
        extra = {
            retrigvar = 3
        }
    },
    loc_txt = {
        ['name'] = 'Kanta Miyamoto',
        ['text'] = {
            [1] = '{C:attention}Queens{} that are {C:attention}scored{} or {C:attention}held',
            [2] = 'in hand{} are retriggered {C:attention}#1#{} times'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 18
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_bzlegends"] = true, ["nx_nx_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.retrigvar}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:get_id() == 12 then
                return {
                    repetitions = card.ability.extra.retrigvar,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.repetition and context.cardarea == G.hand and context.end_of_round and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if context.other_card:get_id() == 12 then
                return {
                    repetitions = card.ability.extra.retrigvar,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.repetition and context.cardarea == G.hand and not context.end_of_round and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if context.other_card:get_id() == 12 then
                return {
                    repetitions = card.ability.extra.retrigvar,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}