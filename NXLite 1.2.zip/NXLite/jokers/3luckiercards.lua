
-- Standalone Joker: Luckier Cards

local LUCKIER_STANDALONE_KEY = "luckier_cards_standalone"
local function luckier_matches_center(card)
    local center_key = card and card.config and card.config.center and card.config.center.key
    return type(center_key) == "string" and center_key:match(LUCKIER_STANDALONE_KEY .. "$") ~= nil
end

SMODS.Joker({
    key = LUCKIER_STANDALONE_KEY,
    loc_txt = {
        name = "Luckier Cards",
        text = {
            "{C:attention}Lucky Cards{} have",
            "{C:green}#1# in #2#{} to retrigger once",
            "{C:green}#1# in #3#{} for {X:mult,C:white}X2{} Mult",
            "{C:green}#1# in #4#{} to create a",
            "random {C:attention}Tag{}",
            "{C:green}#1# in #5#{} to gain",
            "{C:attention}+1 Hand Size{} this run"
        }
    },
    config = { extra = { retrigger_odds = 2, xmult_odds = 4, tag_odds = 8, hand_size_odds = 16, xmult = 2, hand_size = 1 } },
    rarity = 3,
    pos = { x = 2, y = 14 },
    atlas = "CustomJokers",
    cost = 8,
    blueprint_compat = true,
    enhancement_gate = "m_lucky",
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_CENTERS.m_lucky
        return {
            vars = {
                G.GAME.probabilities.normal or 1,
                card.ability.extra.retrigger_odds,
                card.ability.extra.xmult_odds,
                card.ability.extra.tag_odds,
                card.ability.extra.hand_size_odds,
            }
        }
    end,
    calculate = function(self, card, context)
        -- Hard guards: only run when this exact joker card is in the joker area.
        if not luckier_matches_center(card) then
            return
        end
        if card.area ~= G.jokers then
            return
        end

        local other = context.other_card
        local is_lucky = other and other.ability and other.ability.effect == "Lucky Card"
        if not is_lucky then
            return
        end

        if context.repetition and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, "luckier_retrigger", 1, card.ability.extra.retrigger_odds, "luckier_retrigger") then
                return {
                    message = localize("k_again_ex"),
                    repetitions = 1,
                    card = card
                }
            end
        end

        if context.individual and context.cardarea == G.play then
            local out = { card = card }
            local any = false

            if SMODS.pseudorandom_probability(card, "luckier_xmult", 1, card.ability.extra.xmult_odds, "luckier_xmult") then
                out.x_mult = card.ability.extra.xmult
                any = true
            end

            if SMODS.pseudorandom_probability(card, "luckier_tag", 1, card.ability.extra.tag_odds, "luckier_tag") then
                local tag_pool = {}
                for tag_key, tag_center in pairs(G.P_TAGS or {}) do
                    if type(tag_key) == "string"
                        and tag_key:match("^tag_")
                        and tag_center
                        and not tag_center.no_pool_flag
                        and not tag_center.omit
                    then
                        tag_pool[#tag_pool + 1] = tag_key
                    end
                end
                local chosen_tag = #tag_pool > 0 and
                    pseudorandom_element(tag_pool, pseudoseed("luckier_random_tag")) or "tag_double"
                G.E_MANAGER:add_event(Event({
                    func = function()
                        add_tag(Tag(chosen_tag))
                        play_sound("generic1", 0.9 + math.random() * 0.1, 0.8)
                        play_sound("holo1", 1.2 + math.random() * 0.1, 0.4)
                        return true
                    end
                }))
                any = true
            end

            if SMODS.pseudorandom_probability(card, "luckier_hand_size", 1, card.ability.extra.hand_size_odds, "luckier_hand_size") then
                local gain = card.ability.extra.hand_size or 1
                if G.hand and G.hand.change_size then
                    G.hand:change_size(gain)
                    any = true
                end
            end

            if any then
                out.message = "Lucky++"
                out.colour = G.C.GREEN
                return out
            end
        end
    end
})