
SMODS.Joker{ --Mondrian
    key = "2mondrian",
    config = {
        extra = {
            multvar = 1,
            handsremaining = 0
        }
    },
    loc_txt = {
        ['name'] = 'Mondrian',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.1{} Mult for each',
            [2] = '{C:attention}hand{} remaining at {C:attention}end of round{}',
            [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar, ((G.GAME.current_round.hands_left or 0)) * 0.1}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.multvar = (card.ability.extra.multvar) + (G.GAME.current_round.hands_left) * 0.1
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multvar
            }
        end
    end
}