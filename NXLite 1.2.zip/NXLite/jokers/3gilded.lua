
SMODS.Joker{ --Gilded Trading Card
    key = "3gilded",
    config = {
        extra = {
            multvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Gilded Trading Card',
        ['text'] = {
            [1] = 'If {C:attention}first played hand{} contains only {C:attention}1{} card',
            [2] = '{C:red}Destroy{} the card and gain {X:red,C:white}X0.25{} Mult',
            [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar}}
    end,
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if (G.GAME.current_round.hands_played == 0 and to_big(#context.full_hand) == to_big(1)) then
                context.other_card.should_destroy = true
                card.ability.extra.multvar = (card.ability.extra.multvar) + 0.25
                return {
                    message = "Destroyed!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multvar
            }
        end
    end
}