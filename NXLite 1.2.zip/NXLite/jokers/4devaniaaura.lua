
SMODS.Joker{ --Devania Aura
    key = "4devaniaaura",
    config = {
        extra = {
            xmult0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Devania Aura',
        ['text'] = {
            [1] = 'Played {C:hearts}Heart{} cards turns into',
            [2] = '{C:attention}Idol Mark{} cards when scored',
            [3] = '{C:attention}Idol Mark{} cards gives {X:red,C:white}X#1#{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 18
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_bzlegends"] = true, ["nx_nx_jokers"] = true },
    soul_pos = {
        x = 0,
        y = 22
    },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmult0}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:is_suit("Hearts") and not (SMODS.get_enhancements(context.other_card)["m_nx_idolmark"] == true)) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_ability(G.P_CENTERS.m_nx_idolmark)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            elseif SMODS.get_enhancements(context.other_card)["m_nx_idolmark"] == true then
                return {
                    Xmult = card.ability.extra.xmult0
                }
            end
        end
    end
}