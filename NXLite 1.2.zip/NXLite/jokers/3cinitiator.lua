
SMODS.Joker{ --Cult Initiator
    key = "3cinitiator",
    config = {
        extra = {
            specvar = 0,
            chargevar = 0,
            dollars0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Cult Initiator',
        ['text'] = {
            [1] = 'After using {C:attention}3{} {C:spectral}Spectral{} card, gain 1 {C:spectral}Charge{}',
            [2] = 'When entering a {C:attention}Boss Blind{} spend {C:attention}1{} {C:spectral}Charge{}',
            [3] = 'to disable the {C:attention}Boss Blind{} and earn {C:gold}$10{}',
            [4] = '{C:inactive}(Currently{} {C:attention}#1#{}{C:inactive}/3 uses and{} {C:attention}#2#{} {C:inactive}Charges){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true, ["nx_cult"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.specvar, card.ability.extra.chargevar}}
    end,
    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            if (context.consumeable and context.consumeable.ability.set == 'Spectral' and to_big((card.ability.extra.specvar or 0)) ~= to_big(2)) then
                return {
                    func = function()
                        card.ability.extra.specvar = (card.ability.extra.specvar) + 1
                        return true
                    end
                }
            elseif (context.consumeable and context.consumeable.ability.set == 'Spectral' and to_big((card.ability.extra.specvar or 0)) == to_big(2)) then
                return {
                    func = function()
                        card.ability.extra.chargevar = (card.ability.extra.chargevar) + 1
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.specvar = 0
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
        if context.setting_blind  then
            if (G.GAME.blind.boss and to_big((card.ability.extra.chargevar or 0)) > to_big(0)) then
                return {
                    func = function()
                        if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    G.GAME.blind:disable()
                                    play_sound('timpani')
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('ph_boss_disabled'), colour = G.C.GREEN})
                        end
                        return true
                    end,
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 10
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(10), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY,
                        extra = {
                            func = function()
                                card.ability.extra.chargevar = math.max(0, (card.ability.extra.chargevar) - 1)
                                return true
                            end,
                            colour = G.C.RED
                        }
                    }
                }
            end
        end
    end
}