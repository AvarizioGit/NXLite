
SMODS.Joker{ --Chocolate Ice Cream
    key = "2chocolateicecream",
    config = {
        extra = {
            chipvar = 3
        }
    },
    loc_txt = {
        ['name'] = 'Chocolate Ice Cream',
        ['text'] = {
            [1] = '{X:blue,C:white}X#1#{} Chips',
            [2] = '{X:blue,C:white}-X0.1{} Chips for every hand played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chipvar}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big((card.ability.extra.chipvar or 0)) ~= to_big(1.1) then
                return {
                    x_chips = card.ability.extra.chipvar
                }
            elseif to_big((card.ability.extra.chipvar or 0)) == to_big(1.1) then
                local target_joker = card
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
                return {
                    x_chips = card.ability.extra.chipvar
                }
            end
        end
        if context.after and context.cardarea == G.jokers  and not context.blueprint then
            return {
                func = function()
                    card.ability.extra.chipvar = math.max(0, (card.ability.extra.chipvar) - 0.1)
                    return true
                end
            }
        end
    end
}