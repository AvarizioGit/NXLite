
SMODS.Joker{ --Cult Raider
    key = "3craider",
    config = {
        extra = {
            specvar = 0,
            alljokerssellvalue = 1
        }
    },
    loc_txt = {
        ['name'] = 'Cult Raider',
        ['text'] = {
            [1] = 'Increases {C:attention}sell value{} of all Jokers by the',
            [2] = 'amount of {C:spectral}Spectral{} cards {C:attention}used{} this round',
            [3] = 'Adds the {C:attention}sell value{} of all Jokers to {X:red,C:white}XMult{}',
            [4] = '{C:inactive}(Currently{} {X:red,C:white}X#2#{} {C:inactive}Mult and{} {C:attention}#1#{} {C:inactive}cards used){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true, ["nx_cult"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {card.ability.extra.specvar, card.ability.extra.alljokerssellvalue + ((function() local total = 0; for _, joker in ipairs(G.jokers and (G.jokers and G.jokers.cards or {}) or {}) do total = total + joker.sell_cost end; return total end)()) * 0.1}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            local specvar_value = card.ability.extra.specvar
            return {
                func = function()
                    for i, target_card in ipairs(G.jokers.cards) do
                        if target_card.set_cost then
                            target_card.ability.extra_value = (card.ability.extra_value or 0) + specvar_value
                            target_card:set_cost()
                        end
                    end
                    return true
                end,
                message = "All Jokers +"..tostring(specvar_value).." Sell Value",
                extra = {
                    func = function()
                        card.ability.extra.specvar = 0
                        return true
                    end,
                    colour = G.C.BLUE
                }
            }
        end
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Spectral' then
                return {
                    func = function()
                        card.ability.extra.specvar = (card.ability.extra.specvar) + 1
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
            Xmult = card.ability.extra.alljokerssellvalue + ((function() local total = 0; for _, joker in ipairs(G.jokers and G.jokers.cards or {}) do total = total + joker.sell_cost end; return total end)()) * 0.1
            }
        end
    end
}