
SMODS.Joker{ --Crown Jewel of Avarice
    key = "3crownjewelofavarice",
    config = {
        extra = {
            chipvar = 75,
            multvar = 10,
            moneyvar = 2
        }
    },
    loc_txt = {
        ['name'] = 'Crown Jewel of Avarice',
        ['text'] = {
            [1] = 'Played cards with {C:diamonds}Diamond{} suit',
            [2] = 'gives {C:blue}+#1#{} Chips, {C:red}+#2#{} Mult',
            [3] = 'and {C:gold}$#3#{} when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chipvar, card.ability.extra.multvar, card.ability.extra.moneyvar}}
    end,

    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
            or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Diamonds") then
                return {
                    chips = card.ability.extra.chipvar,
                    extra = {
                        mult = card.ability.extra.multvar,
                        extra = {
                            
                            func = function()
                                
                                local current_dollars = G.GAME.dollars
                                local target_dollars = G.GAME.dollars + card.ability.extra.moneyvar
                                local dollar_value = target_dollars - current_dollars
                                ease_dollars(dollar_value)
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2), colour = G.C.MONEY})
                                return true
                            end,
                            colour = G.C.MONEY
                        }
                    }
                }
            end
        end
    end
}