
SMODS.Joker{ --Prospector
    key = "3prospector",
    config = {
        extra = {
            trigswiitch = 0,
            xmultvar = 1,
            payoutvar = 0,
            xmultinc = 0.1,
            payoutinc = 1,
            moneyvar = 5
        }
    },
    loc_txt = {
        ['name'] = 'Prospector',
        ['text'] = {
            [1] = 'Scored {C:attention}Stone cards{} triggers between',
            [2] = 'giving this Joker {X:red,C:white}X#4#{} Mult,',
            [3] = '{C:attention}increases{} payout by {C:gold}$#5#{}. and',
            [4] = 'earns {C:gold}$#6#{} when {C:attention}scored{}',
            [5] = '{C:inactive}(Currently{} {X:red,C:white}X#2#{} {C:inactive}Mult and{} {C:gold}$#3#{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.trigswiitch, card.ability.extra.xmultvar, card.ability.extra.payoutvar, card.ability.extra.xmultinc, card.ability.extra.payoutinc, card.ability.extra.moneyvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_stone"] == true and to_big((card.ability.extra.trigswiitch or 0)) == to_big(1)) then
                card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + card.ability.extra.xmultinc
                card.ability.extra.trigswiitch = pseudorandom('RANGE:1|3', 1, 3)
            elseif (SMODS.get_enhancements(context.other_card)["m_stone"] == true and to_big((card.ability.extra.trigswiitch or 0)) == to_big(2)) then
                card.ability.extra.payoutvar = (card.ability.extra.payoutvar) + card.ability.extra.payoutinc
                card.ability.extra.trigswiitch = pseudorandom('RANGE:1|3', 1, 3)
            elseif (SMODS.get_enhancements(context.other_card)["m_stone"] == true and to_big((card.ability.extra.trigswiitch or 0)) == to_big(3)) then
                card.ability.extra.trigswiitch = pseudorandom('RANGE:1|3', 1, 3)
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + card.ability.extra.moneyvar
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.moneyvar), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
        if context.before and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.trigswiitch = pseudorandom('RANGE:1|3', 1, 3)
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.xmultvar
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + card.ability.extra.payoutvar
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.payoutvar), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}