
SMODS.Joker{ --Outlier
    key = "2outlier",
    config = {
        extra = {
            mod_probability0 = 1,
            mod_probability = 1
        }
    },
    loc_txt = {
        ['name'] = 'Outlier',
        ['text'] = {
            [1] = '{C:attention}Increases{} every {C:green}Numerator{} by {C:attention}1{}',
            [2] = '{C:attention}Decreases{} every {C:green}Denominator{} by {C:attention}1{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.mod_probability  then
            local numerator, denominator = context.numerator, context.denominator
            numerator = numerator + (1)
            denominator = denominator - (1)
            return {
                numerator = numerator, 
                denominator = denominator
            }
        end
    end
}