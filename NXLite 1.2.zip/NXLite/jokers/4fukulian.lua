
SMODS.Joker{ --Fuku Lian
    key = "4fukulian",
    config = {
        extra = {
            basevar = 1.5,
            chipsvar = 1.5,
            incvar = 0.25
        }
    },
    loc_txt = {
        ['name'] = 'Fuku Lian',
        ['text'] = {
            [1] = 'Played {C:attention}2s{}, {C:attention}3s{}, {C:attention}4s{}, and {C:attention}5s{} gives',
            [2] = '{X:blue,C:white}X#2#{} Chips when scored',
            [3] = '{C:attention}Increases{} by {X:blue,C:white}X#3#{} Chips for',
            [4] = 'each consecutive trigger',
            [5] = '{C:inactive}(Resets each hand){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 19
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.basevar, card.ability.extra.chipsvar, card.ability.extra.incvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 3 or context.other_card:get_id() == 4 or context.other_card:get_id() == 5) then
                local chipsvar_value = card.ability.extra.chipsvar
                card.ability.extra.chipsvar = (card.ability.extra.chipsvar) + card.ability.extra.incvar
                return {
                    x_chips = chipsvar_value
                }
            elseif (not (context.other_card:get_id() == 2) or not (context.other_card:get_id() == 3) or not (context.other_card:get_id() == 4) or not (context.other_card:get_id() == 5)) then
                card.ability.extra.chipsvar = card.ability.extra.basevar
            end
        end
        if context.after and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.chipsvar = card.ability.extra.incvar
                    return true
                end
            }
        end
    end
}