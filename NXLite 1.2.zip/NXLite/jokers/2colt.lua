
SMODS.Joker{ --Colt M1911
    key = "2colt",
    config = {
        extra = {
            multvar = 0,
            trigvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Colt M1911',
        ['text'] = {
            [1] = 'This Joker gains {C:red}+11{} Mult every',
            [2] = '{C:attention}19{} {C:inactive}[#2#]{} cards scored',
            [3] = '{C:inactive}(Currently{} {C:red}+#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 24
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar, card.ability.extra.trigvar}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.multvar
            }
        end
        if context.individual and context.cardarea == G.play  then
            if to_big((card.ability.extra.trigvar or 0)) ~= to_big(18) then
                card.ability.extra.trigvar = (card.ability.extra.trigvar) + 1
            elseif to_big((card.ability.extra.trigvar or 0)) == to_big(18) then
                card.ability.extra.trigvar = 0
                card.ability.extra.multvar = (card.ability.extra.multvar) + 11
            end
        end
    end
}