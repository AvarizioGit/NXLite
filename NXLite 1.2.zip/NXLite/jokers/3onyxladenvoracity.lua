
SMODS.Joker{ --Onyx-laden Voracity
    key = "3onyxladenvoracity",
    config = {
        extra = {
            chipvar = 75,
            multvar = 25,
            xmultvar = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Onyx-laden Voracity',
        ['text'] = {
            [1] = 'Played cards with {C:clubs}Club{} suit',
            [2] = 'gives {C:blue}+#1#{} Chips, {C:red}+#2#{} Mult',
            [3] = 'and {X:mult,C:white}X#3#{} Mult when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chipvar, card.ability.extra.multvar, card.ability.extra.xmultvar}}
    end,

    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
            or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Clubs") then
                return {
                    chips = card.ability.extra.chipvar,
                    extra = {
                        mult = card.ability.extra.multvar,
                        extra = {
                            Xmult = card.ability.extra.xmultvar
                        }
                    }
                }
            end
        end
    end
}