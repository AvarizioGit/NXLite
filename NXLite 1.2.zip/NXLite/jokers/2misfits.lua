
SMODS.Joker{ --Misfits
    key = "2misfits",
    config = {
        extra = {
            highestrankinhand = 0
        }
    },
    loc_txt = {
        ['name'] = 'Misfits',
        ['text'] = {
            [1] = 'If played hand is a {C:attention}Four of a Kind{}',
            [2] = 'All {C:attention}scored{} cards gives',
            [3] = 'twice their rank as Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {(((function() local max = 0; for _, card in ipairs(G.play and G.play.cards or {}) do if card.base.id > max then max = card.base.id end end; return max end)() or 0)) * 2}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.scoring_name == "Four of a Kind" then
                return {
                mult = ((function() local max = 0; for _, card in ipairs(G.play and G.play.cards or {}) do if card.base.id > max then max = card.base.id end end; return max end)()) * 2
                }
            end
        end
    end
}