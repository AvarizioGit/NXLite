
SMODS.Joker{ --Jack of All Trades
    key = "2jackofalltrades",
    config = {
        extra = {
            mult0 = 6,
            xmult0 = 1.25,
            dollars0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Jack of All Trades',
        ['text'] = {
            [1] = '{C:attention}Jacks{} gives {C:red}+6{} Mult when {C:attention}scored{}',
            [2] = '{X:red,C:white}X1.25{} Mult when {C:attention}held in hand{}',
            [3] = 'and {C:gold}$1{} at {C:attention}end of round{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 11 then
                return {
                    mult = 6
                }
            elseif (context.other_card:get_id() == 11 and not ((function()
                local enhancements = SMODS.get_enhancements(context.other_card)
                for k, v in pairs(enhancements) do
                    if v then
                        return true
                    end
                end
                return false
            end)()) and not (context.other_card.edition ~= nil) and not (context.other_card.seal ~= nil)) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        local enhancement_pool = {}
                        for _, enhancement in pairs(G.P_CENTER_POOLS.Enhanced) do
                            if enhancement.key ~= 'm_stone' then
                                enhancement_pool[#enhancement_pool + 1] = enhancement
                            end
                        end
                        local random_enhancement = pseudorandom_element(enhancement_pool, 'edit_card_enhancement')
                        scored_card:set_ability(random_enhancement)
                        local random_seal = SMODS.poll_seal({mod = 10, guaranteed = true})
                        if random_seal then
                            scored_card:set_seal(random_seal, true)
                        end
                        local edition = pseudorandom_element({'e_foil','e_holo','e_polychrome','e_negative','e_nx_goldplated'}, 'random edition')
                        if random_edition then
                            scored_card:set_edition(random_edition, true)
                        end
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Jacked!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card:get_id() == 11 then
                return {
                    Xmult = 1.25
                }
            end
        end
        if context.individual and context.cardarea == G.hand and context.end_of_round  then
            if context.other_card:get_id() == 11 then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 1
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
    end
}