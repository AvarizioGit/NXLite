
SMODS.Joker{ --Hot Coffee
    key = "2hotcoffee",
    config = {
        extra = {
            tagvar = 2,
            countvar = 3
        }
    },
    loc_txt = {
        ['name'] = 'Hot Coffee',
        ['text'] = {
            [1] = 'Creates {C:attention}#1#{} random {C:attention}Tags{}',
            [2] = 'after a Blind is defeated',
            [3] = 'Lasts {C:attention}#2#{} rounds'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true, ["nx_food"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.tagvar, card.ability.extra.countvar}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if to_big((card.ability.extra.countvar or 0)) > to_big(1) then
                return {
                    func = function()
                        card.ability.extra.countvar = math.max(0, (card.ability.extra.countvar) - 1)
                        return true
                    end
                    ,
                    func = function()
                        for i = 1, card.ability.extra.tagvar do
                            SMODS.calculate_effect({func = function()
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                        local tag = Tag(selected_tag)
                                        if tag.name == "Orbital Tag" then
                                            local _poker_hands = {}
                                            for k, v in pairs(G.GAME.hands) do
                                                if v.visible then
                                                    _poker_hands[#_poker_hands + 1] = k
                                                end
                                            end
                                            tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                        end
                                        tag:set_ability()
                                        add_tag(tag)
                                        play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                        return true
                                    end
                                }))
                                return true
                            end}, card)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Created Tag!", colour = G.C.GREEN})
                        end
                        return true
                    end
                }
            elseif to_big((card.ability.extra.countvar or 0)) <= to_big(1) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end
                    ,
                    func = function()
                        for i = 1, card.ability.extra.tagvar do
                            SMODS.calculate_effect({func = function()
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                        local tag = Tag(selected_tag)
                                        if tag.name == "Orbital Tag" then
                                            local _poker_hands = {}
                                            for k, v in pairs(G.GAME.hands) do
                                                if v.visible then
                                                    _poker_hands[#_poker_hands + 1] = k
                                                end
                                            end
                                            tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                        end
                                        tag:set_ability()
                                        add_tag(tag)
                                        play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                        return true
                                    end
                                }))
                                return true
                            end}, card)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Created Tag!", colour = G.C.GREEN})
                        end
                        return true
                    end
                }
            end
        end
    end
}