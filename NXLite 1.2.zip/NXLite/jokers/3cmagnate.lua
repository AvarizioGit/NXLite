
SMODS.Joker{ --Cult Magnate
    key = "3cmagnate",
    config = {
        extra = {
            multvar = 1,
            scalevar = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Cult Magnate',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X#1#{} Mult when hand is played',
            [2] = '{C:attention}Kings{} held in hand {C:attention}multiplies{} this value by {X:red,C:white}X#2#{}',
            [3] = 'Using a {C:spectral}Spectral{} card increases the multiplier by {X:red,C:white}X0.1{}',
            [4] = '{C:inactive}(Resets each hand){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true, ["nx_cult"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar, card.ability.extra.scalevar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card:get_id() == 13 then
                return {
                    func = function()
                        card.ability.extra.multvar = (card.ability.extra.multvar) * card.ability.extra.scalevar
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multvar
            }
        end
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Spectral' then
                return {
                    func = function()
                        card.ability.extra.scalevar = (card.ability.extra.scalevar) + 0.1
                        return true
                    end
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.multvar = 1
                    return true
                end
            }
        end
    end
}