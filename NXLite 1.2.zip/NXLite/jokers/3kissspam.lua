
SMODS.Joker{ --Kiss Spam
    key = "3kissspam",
    config = {
        extra = {
            retrigvar = 3
        }
    },
    loc_txt = {
        ['name'] = 'Kiss Spam',
        ['text'] = {
            [1] = 'Retrigger {C:attention}last{} card',
            [2] = 'used in scoring {C:attention}#1#{}',
            [3] = 'additional times'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.retrigvar}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[#context.scoring_hand] then
                return {
                    repetitions = card.ability.extra.retrigvar,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}