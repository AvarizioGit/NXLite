
SMODS.Joker{ --5^2
    key = "3fivesquared",
    config = {
        extra = {
            xmult0 = 2.5
        }
    },
    loc_txt = {
        ['name'] = '5^2',
        ['text'] = {
            [1] = 'If played hand contains {C:attention}exactly 5{} scoring {C:attention}5s{}',
            [2] = 'Each {C:attention}5s {}gives {X:red,C:white}X2.5{} Mult when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 5 and (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if playing_card:get_id() == 5 then
                        count = count + 1
                    end
                end
                return count == 5
            end)()) then
                return {
                    Xmult = 2.5
                }
            end
        end
    end
}