
SMODS.Joker{ --Under Crimson Skies
    key = "3crimsonskies",
    config = {
        extra = {
            odds = 4,
            odds2 = 4,
            consumable_slots0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Under Crimson Skies',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} chance to create a',
            [2] = '{C:spectral}Black Hole{} when {C:attention}hand is played{}',
            [3] = '{C:green}#1# in #2#{} chance to gain {C:attention}+1{}',
            [4] = 'consumable slot at {C:attention}end of round{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
            or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_3crimsonskies')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_nx_3crimsonskies')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_698f2c47', 1, card.ability.extra.odds, 'j_nx_3crimsonskies', false) then
                    for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                        G.E_MANAGER:add_event(Event({
                            trigger = 'after',
                            delay = 0.4,
                            func = function()
                                play_sound('timpani')
                                SMODS.add_card({ set = 'Spectral', key = 'c_black_hole'})                            
                                card:juice_up(0.3, 0.5)
                                return true
                            end
                        }))
                    end
                    delay(0.6)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and localize('k_plus_spectral') or nil, colour = G.C.SECONDARY_SET.Spectral})
                end
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_4c198ca9', 1, card.ability.extra.odds, 'j_nx_3crimsonskies', false) then
                    SMODS.calculate_effect({func = function()
                        G.E_MANAGER:add_event(Event({func = function()
                            G.consumeables.config.card_limit = G.consumeables.config.card_limit + 1
                            return true
                        end }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Consumable Slot", colour = G.C.GREEN})
                        return true
                    end}, card)
                end
            end
        end
    end
}