
SMODS.Joker{ --Paint Bucket
    key = "2paintbucket",
    config = {
        extra = {
            multvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Paint Bucket',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.2{} Mult per consecutive',
            [2] = 'played hand containing a {C:attention}Flush{}',
            [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 24
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar}}
    end,
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if next(context.poker_hands["Flush"]) then
                return {
                    func = function()
                        card.ability.extra.multvar = (card.ability.extra.multvar) + 0.2
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multvar
            }
        end
        if context.after and context.cardarea == G.jokers  then
            if not (next(context.poker_hands["Flush"])) then
                return {
                    func = function()
                        card.ability.extra.multvar = 1
                        return true
                    end
                }
            end
        end
    end
}