
SMODS.Joker{ --Master Challenge
    key = "3masterchallenge",
    config = {
        extra = {
            trigvar = 0,
            dollars0 = 100,
            joker_slots0 = 2,
            ante_value0 = 4,
            ante_value = 4,
            ante_value2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Master Challenge',
        ['text'] = {
            [1] = '{C:attention}+4{} Ante when a {C:attention}Boss Blind{} is defeated',
            [2] = '{C:red}Self destructs{} and {C:attention}-2{} Ante if a',
            [3] = '{C:attention}Blind{} is skipped during this Ante',
            [4] = '{C:attention}-4{} Ante and earn {C:money}$100{} and {C:dark_edition}+2{} Joker',
            [5] = 'slot when {C:attention}Boss Blind{} is defeated'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.trigvar}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            if to_big((card.ability.extra.trigvar or 0)) == to_big(1) then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 100
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(100), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Joker Slot", colour = G.C.DARK_EDITION})
                            G.jokers.config.card_limit = G.jokers.config.card_limit + 2
                            return true
                        end,
                        colour = G.C.DARK_EDITION,
                        extra = {
                            
                            func = function()
                                
                                local mod = -4
                                ease_ante(mod)
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
                                        return true
                                    end,
                                }))
                                return true
                            end,
                            message = "Ante -" .. 4,
                            colour = G.C.YELLOW,
                            extra = {
                                func = function()
                                    local target_joker = card
                                    
                                    if target_joker then
                                        target_joker.getting_sliced = true
                                        G.E_MANAGER:add_event(Event({
                                            func = function()
                                                target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                                return true
                                            end
                                        }))
                                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                                    end
                                    return true
                                end,
                                colour = G.C.RED
                            }
                        }
                    }
                }
            elseif to_big((card.ability.extra.trigvar or 0)) == to_big(0) then
                return {
                    
                    func = function()
                        
                        local mod = 4
                        ease_ante(mod)
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
                                return true
                            end,
                        }))
                        return true
                    end,
                    message = "Ante +" .. 4,
                    extra = {
                        func = function()
                            card.ability.extra.trigvar = 1
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
        if context.skip_blind  then
            if to_big((card.ability.extra.trigvar or 0)) == to_big(1) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end,
                    extra = {
                        
                        func = function()
                            
                            local mod = -2
                            ease_ante(mod)
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
                                    return true
                                end,
                            }))
                            return true
                        end,
                        message = "Ante -" .. 2,
                        colour = G.C.YELLOW
                    }
                }
            end
        end
    end
}