
SMODS.Joker{ --Trash Can
    key = "2trashcan",
    config = {
        extra = {
            dollars0 = 1,
            sell_value0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Trash Can',
        ['text'] = {
            [1] = 'Gives {C:money}$1{} for each card {C:attention}discarded{}',
            [2] = 'Gains {C:money}$1{} as {C:attention}sell value{} each {C:attention}discard{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.discard  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 1
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.pre_discard  then
            return {
                func = function()local my_pos = nil
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i] == card then
                            my_pos = i
                            break
                        end
                    end
                    local target_card = G.jokers.cards[my_pos]
                    target_card.ability.extra_value = (card.ability.extra_value or 0) + 1
                    target_card:set_cost()
                    return true
                end,
                message = "+"..tostring(1).." Sell Value"
            }
        end
    end
}