
SMODS.Joker{ --Mirror
    key = "3mirror",
    config = {
        extra = {
            steelcardsinhand = 0
        }
    },
    loc_txt = {
        ['name'] = 'Mirror',
        ['text'] = {
            [1] = '{C:attention}Retrigger{} scored cards for',
            [2] = 'each {C:attention}Glass{} card held in hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 23
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {((function() local count = 0; for _, card in ipairs(G.hand and G.hand.cards or {}) do if SMODS.has_enhancement(card, 'm_glass') then count = count + 1 end end; return count end)() or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            return {
            repetitions = (function() local count = 0; for _, card in ipairs(G.hand and G.hand.cards or {}) do if SMODS.has_enhancement(card, 'm_glass') then count = count + 1 end end; return count end)(),
                message = localize('k_again_ex')
            }
        end
    end
}