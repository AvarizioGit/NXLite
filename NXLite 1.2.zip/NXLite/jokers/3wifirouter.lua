
SMODS.Joker{ --WiFi Router
    key = "3wifirouter",
    config = {
        extra = {
            Xmult = 2,
            odds = 4,
            mult = 4,
            chips = 30,
            chips2 = 50,
            odds2 = 5,
            odds2 = 15,
            mult2 = 20,
            dollars = 20
        }
    },
    loc_txt = {
        ['name'] = 'WiFi Router',
        ['text'] = {
            [1] = 'Cards with {C:attention}Vanilla{} {C:enhanced}Enhancements{} that',
            [2] = 'triggers when scored now also',
            [3] = '{C:attention}trigger{} their effects when {C:attention}held in hand{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 17
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_glass"] == true then
                return {
                    Xmult = 2
                }
            elseif SMODS.get_enhancements(context.other_card)["m_mult"] == true then
                return {
                    mult = 4
                }
            elseif SMODS.get_enhancements(context.other_card)["m_bonus"] == true then
                return {
                    chips = 30
                }
            elseif SMODS.get_enhancements(context.other_card)["m_stone"] == true then
                return {
                    chips = 50
                }
            elseif SMODS.get_enhancements(context.other_card)["m_lucky"] == true then
                return {
                    mult = 20,
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 20
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(20), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY
                    }
                }
            end
        end
    end
}