
SMODS.Joker{ --Kingbo
    key = "2kingbo",
    config = {
        extra = {
            multvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Kingbo',
        ['text'] = {
            [1] = 'Cards {C:attention}held in hand{} gives {X:red,C:white}X0.4{} Mult to this Joker',
            [2] = 'Unleashes accumulated {X:red,C:white}XMult{} when {C:attention}hand is played{}',
            [3] = '{C:inactive}(Previously{} {X:red,C:white}X#1#{} {C:inactive}Mult, resets after each hand){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 22
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'uta' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            return {
                func = function()
                    card.ability.extra.multvar = (card.ability.extra.multvar) + 0.4
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multvar
            }
        end
        if context.before and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.multvar = 1
                    return true
                end
            }
        end
    end
}