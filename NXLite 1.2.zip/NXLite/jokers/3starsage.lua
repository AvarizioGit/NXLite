
SMODS.Joker{ --Stars of Age-Rumnoi
    key = "3starsage",
    config = {
        extra = {
            multvar = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Stars of Age-Rumnoi',
        ['text'] = {
            [1] = 'Played {C:diamonds}Diamonds{} gives {X:red,C:white}X#1#{} when {C:attention}scored{}',
            [2] = 'Multiply it by {X:red,C:white}X1.1{} when a {C:planet}Planet{} card is used',
            [3] = '{C:inactive}(Resets each Ante){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 16
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Diamonds") then
                return {
                    Xmult = card.ability.extra.multvar
                }
            end
        end
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Planet' then
                return {
                    func = function()
                        card.ability.extra.multvar = (card.ability.extra.multvar) * 1.1
                        return true
                    end
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            return {
                func = function()
                    card.ability.extra.multvar = 1.1
                    return true
                end
            }
        end
    end
}