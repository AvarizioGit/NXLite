
SMODS.Joker{ --Photochad
    key = "3photochad",
    config = {
        extra = {
            xmultvar = 2,
            retrigvar = 2
        }
    },
    loc_txt = {
        ['name'] = 'Photochad',
        ['text'] = {
            [1] = 'First played {C:attention}face{} card',
            [2] = 'gives {X:red,C:white}X#1#{} Mult when scored',
            [3] = 'and retriggers {C:attention}#2#{} times',
            [4] = ' ',
            [5] = '{C:inactive}>Looks Inside{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmultvar, card.ability.extra.retrigvar}}
    end,
    
    calculate = function(self, card, context)
        if (context.individual or context.repetition) and context.cardarea == G.play  then
            if (function()
                for i = 1, #context.scoring_hand do
                    local scoring_card = context.scoring_hand[i]
                    if scoring_card:is_face() then
                        return scoring_card == context.other_card
                    end
                end
                return false
            end)() then
                return {
                    repetitions = card.ability.extra.retrigvar,
                        message = localize('k_again_ex'),
                    extra = {
                        Xmult = card.ability.extra.xmultvar,
                    }
                }
            end
        end
    end
}