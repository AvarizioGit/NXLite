
SMODS.Joker{ --Stars Aligned
    key = "3starsaligned",
    config = {
        extra = {
            levels0 = 1,
            levels = 1
        }
    },
    loc_txt = {
        ['name'] = 'Stars Aligned',
        ['text'] = {
            [1] = 'When a {C:planet}Planet{} card is used',
            [2] = 'level up {C:attention}2{} random poker hands'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 16
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Planet' then
                local available_hands = {}
                for hand, value in pairs(G.GAME.hands) do
                    if value.visible and value.level >= to_big(1) then
                        table.insert(available_hands, hand)
                    end
                end
                local target_hand = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
                level_up_hand(card, target_hand, true, 1)
                local available_hands = {}
                for hand, value in pairs(G.GAME.hands) do
                    if value.visible and value.level >= to_big(1) then
                        table.insert(available_hands, hand)
                    end
                end
                local target_hand2 = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
                level_up_hand(card, target_hand2, true, 1)
                return {
                    message = localize('k_level_up_ex'),
                    extra = {
                        message = localize('k_level_up_ex'),
                        colour = G.C.RED
                    }
                }
            end
        end
    end
}