
SMODS.Joker{ --Plus One
    key = "3plusone",
    config = {
        extra = {
            incvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Plus One',
        ['text'] = {
            [1] = '{C:attention}+#1#{} Hands',
            [2] = '{C:attention}+#1#{} Discards',
            [3] = '{C:attention}+#1#{} Hand size',
            [4] = '{C:attention}+#1#{} Joker slot',
            [5] = '{C:attention}+#1#{} Card selection limit'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 23
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.incvar}}
    end,
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.extra.incvar
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + card.ability.extra.incvar
        G.hand:change_size(card.ability.extra.incvar)
        SMODS.change_discard_limit(card.ability.extra.incvar)
        SMODS.change_play_limit(card.ability.extra.incvar)
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.incvar
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.incvar
            return true
        end }))
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands - card.ability.extra.incvar
        G.GAME.round_resets.discards = G.GAME.round_resets.discards - card.ability.extra.incvar
        G.hand:change_size(-card.ability.extra.incvar)
        SMODS.change_discard_limit(-card.ability.extra.incvar)
        SMODS.change_play_limit(-card.ability.extra.incvar)
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.incvar
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.incvar
            return true
        end }))
    end
}