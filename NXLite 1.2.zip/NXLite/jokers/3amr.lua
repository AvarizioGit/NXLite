
SMODS.Joker{ --Anti-Material Rifle
    key = "3amr",
    config = {
        extra = {
            multvar = 1,
            gainvar = 0.25
        }
    },
    loc_txt = {
        ['name'] = 'Anti-Material Rifle',
        ['text'] = {
            [1] = '{C:rare}Destroys{} leftmost Joker when {C:attention}Blind{}',
            [2] = '{C:attention}is selected{} and gains {X:red,C:white}X#2#{} Mult',
            [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}',
            [4] = '{C:inactive}(Bypasses Eternal){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 24
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar, card.ability.extra.gainvar}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if not ((function()
                return G.jokers.cards[1] == card
            end)()) then
                return {
                    func = function()
                        local target_joker = nil
                        for i, joker in ipairs(G.jokers.cards) do
                            if joker ~= card and not joker.getting_sliced then
                                target_joker = joker
                                break
                            end
                        end
                        
                        if target_joker then
                            if target_joker.ability.eternal then
                                target_joker.ability.eternal = nil
                            end
                            local joker_sell_value = target_joker.sell_cost or 0
                            local sell_value_gain = joker_sell_value * card.ability.extra.gainvar
                            card.ability.extra.multvar = card.ability.extra.multvar + sell_value_gain
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:shatter({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multvar
            }
        end
    end
}