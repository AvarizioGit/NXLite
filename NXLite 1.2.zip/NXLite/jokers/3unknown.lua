
SMODS.Joker{ --???
    key = "3unknown",
    config = {
        extra = {
            slotvar = 0,
            odds = 13,
            addvar = 1
        }
    },
    loc_txt = {
        ['name'] = '???',
        ['text'] = {
            [1] = '{C:green}#2# in #3#{} chance to gain {C:dark_edition}+#4#{}',
            [2] = 'Joker slot when a Joker is {C:attention}sold{}',
            [3] = '{C:inactive}(Triggers once per ante){}',
            [4] = '{C:inactive}(Currently{} {C:dark_edition}+#1#{} {C:inactive}Joker slots){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 23
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_3unknown') 
        return {vars = {card.ability.extra.slotvar, new_numerator, new_denominator, card.ability.extra.addvar}}
    end,
    
    calculate = function(self, card, context)
        if context.selling_card and context.card.ability.set == "Joker" then
            if (G.GAME.pool_flags.nx_slotflag or false) then
                if SMODS.pseudorandom_probability(card, 'group_0_8a8b01f2', 1, card.ability.extra.odds, 'j_nx_3unknown', false) then
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            card:juice_up(0.3, 0.5)
                            card_eval_status_text(card, 'extra', nil, nil, nil, {message = "slotflag", colour = G.C.BLUE})
                            G.GAME.pool_flags.nx_slotflag = false
                            return true
                        end
                    }))
                    SMODS.calculate_effect({func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Joker Slot", colour = G.C.DARK_EDITION})
                        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.addvar
                        return true
                    end}, card)
                    SMODS.calculate_effect({func = function()
                        card.ability.extra.slotvar = (card.ability.extra.slotvar) + card.ability.extra.addvar
                        return true
                    end}, card)
                end
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card:juice_up(0.3, 0.5)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "slotflag", colour = G.C.BLUE})
                    G.GAME.pool_flags.nx_slotflag = true
                    return true
                end
            }))
        end
    end
}