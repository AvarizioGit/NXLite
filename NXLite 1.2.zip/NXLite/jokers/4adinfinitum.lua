
SMODS.Joker{ --Ad Infinitum
    key = "4adinfinitum",
    config = {
        extra = {
            retrigvar = 10
        }
    },
    loc_txt = {
        ['name'] = 'Ad Infinitum',
        ['text'] = {
            [1] = 'Retrigger {C:attention}first{} scored',
            [2] = 'card {C:attention}#1#{} times'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 18
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    soul_pos = {
        x = 6,
        y = 19
    },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.retrigvar}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[1] then
                return {
                    repetitions = card.ability.extra.retrigvar,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}