
SMODS.Joker{ --Fair Blair
    key = "2fairblair",
    config = {
        extra = {
            mult0 = 8,
            xmult0 = 1.4
        }
    },
    loc_txt = {
        ['name'] = 'Fair Blair',
        ['text'] = {
            [1] = 'Played cards with {C:attention}even{} rank gives',
            [2] = '{C:red}+8{} Mult when {C:attention}scored{} and {X:red,C:white}X1.4{}',
            [3] = 'Mult when {C:attention}held in hand{}',
            [4] = '{C:inactive} (10, 8, 6, 4, 2){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 22
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'uta' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) then
                return {
                    mult = 8
                }
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) then
                return {
                    Xmult = 1.4
                }
            end
        end
    end
}