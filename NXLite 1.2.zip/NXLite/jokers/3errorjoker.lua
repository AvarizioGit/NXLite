
SMODS.Joker{ --Error Joker
    key = "3errorjoker",
    config = {
        extra = {
            xmult0_min = NaN,
            xmult0_max = 10
        }
    },
    loc_txt = {
        ['name'] = 'Error Joker',
        ['text'] = {
            [1] = '{X:red,C:white}X0.1{}-{X:red,C:white}X10{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = pseudorandom('RANGE:0.1|10', 0.1, 10)
            }
        end
    end
}