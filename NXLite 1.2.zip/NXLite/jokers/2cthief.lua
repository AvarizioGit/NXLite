
SMODS.Joker{ --Cult Thief
    key = "2cthief",
    config = {
        extra = {
            discards0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Cult Thief',
        ['text'] = {
            [1] = 'Creates a {C:spectral}Spectral{} card when {C:attention}hand is played{}',
            [2] = '{C:attention}Sets{} discards to {C:red}0{} when {C:attention}Blind is selected{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true, ["nx_cult"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.4,
                    func = function()
                        play_sound('timpani')
                        SMODS.add_card({ set = 'Spectral', })                            
                        card:juice_up(0.3, 0.5)
                        return true
                    end
                }))
            end
            delay(0.6)
            return {
                message = created_consumable and localize('k_plus_spectral') or nil
            }
        end
        if context.setting_blind  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(1).." Discards", colour = G.C.BLUE})
                    G.GAME.current_round.discards_left = 0
                    return true
                end
            }
        end
    end
}