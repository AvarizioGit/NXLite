
SMODS.Joker{ --Envelope
    key = "2envelope",
    config = {
        extra = {
            Chipvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Envelope',
        ['text'] = {
            [1] = 'Gains {C:blue}+10{} Chips when',
            [2] = 'a {C:attention}Seal{} is triggered',
            [3] = '{C:inactive}(Currently{} {C:blue}+#1#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Chipvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card.seal == "Red" or context.other_card.seal == "Gold") then
                card.ability.extra.Chipvar = (card.ability.extra.Chipvar) + 10
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card.seal == "Red" then
                return {
                    func = function()
                        card.ability.extra.Chipvar = (card.ability.extra.Chipvar) + 10
                        return true
                    end
                }
            end
        end
        if context.discard  then
            if context.other_card.seal == "Purple" then
                return {
                    func = function()
                        card.ability.extra.Chipvar = (card.ability.extra.Chipvar) + 10
                        return true
                    end
                }
            end
        end
        if context.individual and context.cardarea == G.hand and context.end_of_round  then
            if context.other_card.seal == "Blue" then
                return {
                    func = function()
                        card.ability.extra.Chipvar = (card.ability.extra.Chipvar) + 10
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.Chipvar
            }
        end
    end
}