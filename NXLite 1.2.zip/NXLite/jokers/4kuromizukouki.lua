
SMODS.Joker{ --Kuromizu Kouki
    key = "4kuromizukouki",
    config = {
        extra = {
            SteelVar = 1.5,
            addvar = 0.02
        }
    },
    loc_txt = {
        ['name'] = 'Kuromizu Kouki',
        ['text'] = {
            [1] = '{C:attention}Steel{} cards additionally gives',
            [2] = '{X:blue,C:white}X#1#{} Chips when {C:attention}held{}',
            [3] = 'Increases by {X:blue,C:white}X#2#{} for each',
            [4] = '{C:attention}Steel{} card at {C:attention}end of round{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 18
    },

    soul_pos = {
        x = 4,
        y = 18
    },

    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_bzlegends"] = true, ["nx_nx_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.SteelVar, card.ability.extra.addvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    x_chips = card.ability.extra.SteelVar
                }
            end
        end
        if context.individual and context.cardarea == G.hand and context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    func = function()
                        card.ability.extra.SteelVar = (card.ability.extra.SteelVar) + card.ability.extra.addvar
                        return true
                    end,
                    message = "Upgrade!"
                }
            end
        end
    end
}