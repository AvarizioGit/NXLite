
SMODS.Joker{ --Omnicard
    key = "3omnicard",
    config = {
        extra = {
            bonusvar = 1,
            xmultvar = 0.1,
            chipvar = 10,
            multvar = 2,
            moneyvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Omnicard',
        ['text'] = {
            [1] = '{C:attention}Wild{} cards gains a permanent',
            [2] = '{C:attention}Bonus{} between {C:blue}+#2#{} Chips, {C:red}+#3#{} Mult,',
            [3] = '{X:red,C:white}X#4#{} Mult, and {C:gold}$#5#{} when scored',
            [4] = '{C:attention}Wild{} cards cannot be debuffed'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.bonusvar, card.ability.extra.chipvar, card.ability.extra.multvar, card.ability.extra.xmultvar, card.ability.extra.moneyvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_wild"] == true and to_big((card.ability.extra.bonusvar or 0)) == to_big(1)) then
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.xmultvar
                card.ability.extra.bonusvar = pseudorandom('RANGE:1|4', 1, 4)
                return {
                    extra = { message = "XMult!", colour = G.C.MULT }, card = card
                }
            elseif (SMODS.get_enhancements(context.other_card)["m_wild"] == true and to_big((card.ability.extra.bonusvar or 0)) == to_big(2)) then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + card.ability.extra.chipvar
                card.ability.extra.bonusvar = pseudorandom('RANGE:1|4', 1, 4)
            elseif (SMODS.get_enhancements(context.other_card)["m_wild"] == true and to_big((card.ability.extra.bonusvar or 0)) == to_big(3)) then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.multvar
                card.ability.extra.bonusvar = pseudorandom('RANGE:1|4', 1, 4)
            elseif (SMODS.get_enhancements(context.other_card)["m_wild"] == true and to_big((card.ability.extra.bonusvar or 0)) == to_big(4)) then
                context.other_card.ability.perma_p_dollars = context.other_card.ability.perma_p_dollars or 0
                context.other_card.ability.perma_p_dollars = context.other_card.ability.perma_p_dollars + card.ability.extra.moneyvar
                card.ability.extra.bonusvar = pseudorandom('RANGE:1|4', 1, 4)
            end
        end
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.bonusvar = pseudorandom('RANGE:1|4', 1, 4)
                    return true
                end
            }
        end
        if context.setting_blind  then
            if (to_big((card.ability.extra.bonusvar or 0)) ~= to_big(1) and to_big((card.ability.extra.bonusvar or 0)) ~= to_big(2) and to_big((card.ability.extra.bonusvar or 0)) ~= to_big(3) and to_big((card.ability.extra.bonusvar or 0)) ~= to_big(4)) then
                return {
                    func = function()
                        card.ability.extra.bonusvar = 1
                        return true
                    end
                }
            end
        end
    end
}

    SMODS.current_mod.set_debuff = function(card)
        if next(SMODS.find_card("j_nx_3omnicard")) and card.playing_card and SMODS.has_enhancement(card, "m_wild") then
            return "prevent_debuff"
        end
    end