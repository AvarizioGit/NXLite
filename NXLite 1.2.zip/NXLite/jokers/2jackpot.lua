
SMODS.Joker{ --Jackpot!
    key = "2jackpot",
    config = {
        extra = {
            sevenvar = 0,
            dollars0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Jackpot!',
        ['text'] = {
            [1] = 'Gives {C:money}$10{} after scoring',
            [2] = 'a {C:attention}7{} three times',
            [3] = '{C:inactive}(Currently{} {C:attention}#1#{}{C:inactive}/3 times){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.sevenvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 7 and to_big((card.ability.extra.sevenvar or 0)) ~= to_big(2)) then
                card.ability.extra.sevenvar = (card.ability.extra.sevenvar) + 1
            elseif (context.other_card:get_id() == 7 and to_big((card.ability.extra.sevenvar or 0)) == to_big(2)) then
                card.ability.extra.sevenvar = 0
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 10
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(10), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
    end
}