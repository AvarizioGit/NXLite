
SMODS.Joker{ --Karbit
    key = "3karbit",
    config = {
        extra = {
            handvar = 0,
            handsizevar = 2
        }
    },
    loc_txt = {
        ['name'] = 'Karbit',
        ['text'] = {
            [1] = 'If {C:attention}discarded{} hand',
            [2] = 'contains a {C:attention}face{} card',
            [3] = 'Gain {C:attention}+2{} Hand size',
            [4] = 'for the round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.handvar, card.ability.extra.handsizevar}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            local handvar_value = card.ability.extra.handvar
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(handvar_value).." Hand Limit", colour = G.C.BLUE})
                    
                    G.hand:change_size(-handvar_value)
                    return true
                end,
                extra = {
                    func = function()
                        card.ability.extra.handvar = 0
                        return true
                    end,
                    colour = G.C.BLUE
                }
            }
        end
        if context.pre_discard and not context.blueprint then
            if (function()
                local rankCount = 0
                for i, c in ipairs(context.full_hand) do
                    if c:is_face() then
                        rankCount = rankCount + 1
                    end
                end
                
                return rankCount >= 1
            end)() then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(3).." Hand Limit", colour = G.C.BLUE})
                        
                        G.hand:change_size(card.ability.extra.handsizevar)
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.handvar = (card.ability.extra.handvar) + card.ability.extra.handsizevar
                            return true
                        end,
                        colour = G.C.GREEN
                    }
                }
            end
        end
    end
}