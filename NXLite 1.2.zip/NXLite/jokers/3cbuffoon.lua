
SMODS.Joker{ --Cult Buffoon
    key = "3cbuffoon",
    config = {
        extra = {
            xmultvar = 2
        }
    },
    loc_txt = {
        ['name'] = 'Cult Buffoon',
        ['text'] = {
            [1] = '{C:attention}Cult Jokers{} each gives {X:red,C:white}X#1#{}',
            [2] = 'Mult when {C:attention}hand is played{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true, ["nx_cult"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmultvar}}
    end,
    
    calculate = function(self, card, context)
        if context.other_joker  then
            if (context.other_joker.config.center.key == "j_nx_3cinitiator" or context.other_joker.config.center.key == "j_nx_3cmagnate" or context.other_joker.config.center.key == "j_nx_3craider" or context.other_joker.config.center.key == "j_nx_3cpathfinder" or context.other_joker.config.center.key == "j_nx_2cmessenger" or context.other_joker.config.center.key == "j_nx_2cthespian" or context.other_joker.config.center.key == "j_nx_2cascender" or context.other_joker.config.center.key == "j_nx_2cadept" or context.other_joker.config.center.key == "j_nx_2cviscount" or context.other_joker.config.center.key == "j_nx_2cthief" or context.other_joker.config.center.key == "j_nx_2cmerchant" or context.other_joker.config.center.key == "j_nx_2cpriest" or context.other_joker.config.center.key == "j_nx_2fatesayer" or context.other_joker.config.center.key == "j_nx_1czealot" or context.other_joker.config.center.key == "j_nx_3cbuffoon") then
                return {
                    Xmult = card.ability.extra.xmultvar
                }
            end
        end
    end
}