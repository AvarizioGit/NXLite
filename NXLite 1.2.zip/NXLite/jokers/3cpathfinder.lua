
SMODS.Joker{ --Cult Pathfinder
    key = "3cpathfinder",
    config = {
        extra = {
            chipvar = 150,
            handsizevar = 0,
            hand_size0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Cult Pathfinder',
        ['text'] = {
            [1] = 'Gains {C:blue}+50{} Chips and {C:attention}+1{} hand size this',
            [2] = 'round when a {C:spectral}Spectral{} card is used',
            [3] = '{C:inactive}(Currently{} {C:blue}+#1#{} {C:inactive}Chips and{} {C:attention}+#2#{} {C:inactive}hand size){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true, ["nx_cult"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chipvar, card.ability.extra.handsizevar}}
    end,
    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Spectral' then
                return {
                    func = function()
                        card.ability.extra.chipvar = (card.ability.extra.chipvar) + 50
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.handsizevar = (card.ability.extra.handsizevar) + 1
                            return true
                        end,
                        colour = G.C.GREEN,
                        extra = {
                            
                            func = function()
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Hand Limit", colour = G.C.BLUE})
                                
                                G.hand:change_size(1)
                                return true
                            end,
                            colour = G.C.WHITE
                        }
                    }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.chipvar
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            local handsizevar_value = card.ability.extra.handsizevar
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(handsizevar_value).." Hand Limit", colour = G.C.BLUE})
                    
                    G.hand:change_size(-handsizevar_value)
                    return true
                end,
                extra = {
                    func = function()
                        card.ability.extra.handsizevar = 0
                        return true
                    end,
                    colour = G.C.BLUE
                }
            }
        end
    end
}