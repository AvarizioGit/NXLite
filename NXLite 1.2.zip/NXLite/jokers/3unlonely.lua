
SMODS.Joker{ --Un-Lonely
    key = "3unlonely",
    config = {
        extra = {
            source_rank_type = 'all',
            source_ranks = '{}',
            target_rank = '"2"'
        }
    },
    loc_txt = {
        ['name'] = 'Un-Lonely',
        ['text'] = {
            [1] = 'All cards are',
            [2] = 'considered as {C:attention}2s{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 17
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        -- Combine ranks effect enabled
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        -- Combine ranks effect disabled
    end
}


local card_get_id_ref = Card.get_id
function Card:get_id()
    local original_id = card_get_id_ref(self)
    if not original_id then return original_id end

    if next(SMODS.find_card("j_nx_3unlonely")) then
        return 2
    end
    return original_id
end
