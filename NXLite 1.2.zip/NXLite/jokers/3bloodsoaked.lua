
SMODS.Joker{ --Blood-soaked Temptation
    key = "3bloodsoaked",
    config = {
        extra = {
            chipvar = 75,
            multvar = 10,
            odds = 2,
            xmultvar = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'Blood-soaked Temptation',
        ['text'] = {
            [1] = 'Played cards with {C:hearts}Heart{} suit gives',
            [2] = '{C:blue}+#3#{} Chips and {C:red}+#4#{} Mult and a {C:green}#1# in #2#{}',
            [3] = 'chance to give {X:red,C:white}X#5#{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
            or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_3bloodsoaked') 
        return {vars = {new_numerator, new_denominator, card.ability.extra.chipvar, card.ability.extra.multvar, card.ability.extra.xmultvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    chips = card.ability.extra.chipvar,
                    extra = {
                        mult = card.ability.extra.multvar
                    }
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_d1eacd8d', 1, card.ability.extra.odds, 'j_nx_3bloodsoaked', false) then
                            SMODS.calculate_effect({Xmult = card.ability.extra.xmultvar}, card)
                        end
                        return true
                    end
                }
            end
        end
    end
}