
SMODS.Joker{ --Kingslayer
    key = "3kingslayer",
    config = {
        extra = {
            blindvar = 10,
            antevar = 2
        }
    },
    loc_txt = {
        ['name'] = 'Kingslayer',
        ['text'] = {
            [1] = 'Divides {C:attention}Boss Blind{} requirements by {C:attention}#1#{}',
            [2] = '{C:attention}-#2#{} Ante and {C:red}self destructs{} if Boss Blind',
            [3] = 'is cleared with {C:blue}0{} hands remaining'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.blindvar, card.ability.extra.antevar}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    
                    func = function()
                        if G.GAME.blind.in_blind then
                            
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Weakened!", colour = G.C.GREEN})
                            G.GAME.blind.chips = G.GAME.blind.chips / card.ability.extra.blindvar
                            G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                            G.HUD_blind:recalculate()
                            return true
                        end
                    end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (to_big(G.GAME.current_round.hands_left) == to_big(0) and G.GAME.blind.boss) then
                return {
                    
                    func = function()
                        
                        local mod = -card.ability.extra.antevar
                        ease_ante(mod)
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
                                return true
                            end,
                        }))
                        return true
                    end,
                    message = "Ante -" .. 1,
                    extra = {
                        func = function()
                            local target_joker = card
                            
                            if target_joker then
                                target_joker.getting_sliced = true
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                        return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                            end
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
    end
}