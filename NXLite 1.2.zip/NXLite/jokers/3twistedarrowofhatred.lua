
SMODS.Joker{ --Twisted Arrow of Hatred
    key = "3twistedarrowofhatred",
    config = {
        extra = {
            chips0 = 175,
            mult0 = 10,
            xchips0 = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Twisted Arrow of Hatred',
        ['text'] = {
            [1] = 'Played cards with {C:spades}Spade{} suit',
            [2] = 'gives {C:blue}+#1#{} Chips, {C:red}+#2#{} Mult',
            [3] = 'and {X:blue,C:white}X#3#{} Chips when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chips0, card.ability.extra.mult0, card.ability.extra.xchips0}}
    end,

    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
            or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Spades") then
                return {
                    chips = card.ability.extra.chips0,
                    extra = {
                        mult = card.ability.extra.mult0,
                        extra = {
                            x_chips = card.ability.extra.xchips0,
                            colour = G.C.DARK_EDITION
                        }
                    }
                }
            end
        end
    end
}