
SMODS.Joker{ --Chain Gun
    key = "3chaingun",
    config = {
        extra = {
            trigvar = 1,
            xmult0 = 1.5,
            limitvar = 15
        }
    },
    loc_txt = {
        ['name'] = 'Chain Gun',
        ['text'] = {
            [1] = '{X:red,C:white}X#2#{} Mult',
            [2] = 'Retriggers {C:attention}0-#3#{} times',
            [3] = '{C:inactive}(Previously #1# times){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 24
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.trigvar, card.ability.extra.xmult0, card.ability.extra.limitvar}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                for i = 1, card.ability.extra.trigvar do
                    SMODS.calculate_effect({Xmult = card.ability.extra.xmult0}, card)
                end
            end
        end
        if context.after and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.trigvar = pseudorandom('RANGE:1|16', 1, card.ability.extra.limitvar)
                    return true
                end
            }
        end
    end
}