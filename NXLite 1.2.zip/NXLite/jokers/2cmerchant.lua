
SMODS.Joker{ --Cult Merchant
    key = "2cmerchant",
    config = {
        extra = {
            rollvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Cult Merchant',
        ['text'] = {
            [1] = 'Creates an {C:spectral}Ethereal{} tag every',
            [2] = '{C:attention}10{} {C:green}Rerolls{} of the shop',
            [3] = '{C:inactive}(Currently{} {C:attention}#1#{}{C:inactive}/10 Rerolls){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true, ["nx_cult"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.rollvar}}
    end,
    
    calculate = function(self, card, context)
        if context.reroll_shop  then
            if to_big((card.ability.extra.rollvar or 0)) ~= to_big(9) then
                return {
                    func = function()
                        card.ability.extra.rollvar = (card.ability.extra.rollvar) + 1
                        return true
                    end
                }
            elseif to_big((card.ability.extra.rollvar or 0)) == to_big(9) then
                return {
                    func = function()
                        card.ability.extra.rollvar = 0
                        return true
                    end,
                    extra = {
                        func = function()
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local tag = Tag("tag_ethereal")
                                    if tag.name == "Orbital Tag" then
                                        local _poker_hands = {}
                                        for k, v in pairs(G.GAME.hands) do
                                            if v.visible then
                                                _poker_hands[#_poker_hands + 1] = k
                                            end
                                        end
                                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                    end
                                    tag:set_ability()
                                    add_tag(tag)
                                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                    return true
                                end
                            }))
                            return true
                        end,
                        message = "Created Tag!",
                        colour = G.C.GREEN
                    }
                }
            end
        end
    end
}