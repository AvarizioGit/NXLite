
SMODS.Joker{ --Idolizing Joker
    key = "2idolizingjoker",
    config = {
        extra = {
            moneyvar = 1,
            xmultvar = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'Idolizing Joker',
        ['text'] = {
            [1] = '{C:attention}Idol Mark Cards{} gives {C:gold}$#1#{}',
            [2] = 'and {X:red,C:white}X#2#{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.moneyvar, card.ability.extra.xmultvar}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_nx_idolmark"] == true then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + card.ability.extra.moneyvar
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.moneyvar), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        Xmult = card.ability.extra.xmultvar
                    }
                }
            end
        end
    end
}