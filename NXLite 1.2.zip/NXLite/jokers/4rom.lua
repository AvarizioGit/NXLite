
SMODS.Joker{ --Radix Omnium Malorum
    key = "4rom",
    config = {
        extra = {
            payoutvar = 50,
            shopvar = 2,
            sellvar = 5
        }
    },
    loc_txt = {
        ['name'] = 'Radix Omnium Malorum',
        ['text'] = {
            [1] = 'Earn {C:gold}$#1#{} and gains {C:gold}$#3#{} of',
            [2] = 'sell value at {C:attention}end of round{}',
            [3] = '{C:attention}+#2#{} Shop slots'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 19
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    soul_pos = {
        x = 8,
        y = 19
    },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.payoutvar, card.ability.extra.shopvar, card.ability.extra.sellvar}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + card.ability.extra.payoutvar
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.payoutvar), colour = G.C.MONEY})
                    return true
                end,
                extra = {
                    func = function()local my_pos = nil
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i] == card then
                                my_pos = i
                                break
                            end
                        end
                        local target_card = G.jokers.cards[my_pos]
                        target_card.ability.extra_value = (card.ability.extra_value or 0) + card.ability.extra.sellvar
                        target_card:set_cost()
                        return true
                    end,
                    message = "+"..tostring(card.ability.extra.sellvar).." Sell Value",
                    colour = G.C.MONEY
                }
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        change_shop_size(card.ability.extra.shopvar)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        change_shop_size(-card.ability.extra.shopvar)
    end
}