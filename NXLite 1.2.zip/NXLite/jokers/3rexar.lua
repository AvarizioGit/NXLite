
SMODS.Joker{ --Rexar
    key = "3rexar",
    config = {
        extra = {
            chipvar = 1,
            incvar = 0.3,
            emptyvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Rexar',
        ['text'] = {
            [1] = '{C:red}Destroys{} a random {C:attention}consumable{}',
            [2] = 'when {C:attention}Blind{} is selected',
            [3] = 'Gains {X:blue,C:white}X#2#{} Chips for each',
            [4] = '{C:attention}consumable{} destroyed',
            [5] = '{C:inactive}(Currently{} {X:blue,C:white}X#1#{} {C:inactive}Chips){}',
            [6] = ' ',
            [7] = '{C:inactive}Do not let him starve{}',
            [8] = '{C:inactive}#3#/3 times in a row...{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_nx_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chipvar, card.ability.extra.incvar, card.ability.extra.emptyvar}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  and not context.blueprint then
            if to_big(#G.consumeables.cards) >= to_big(1) then
                return {
                    func = function()
                        local target_cards = {}
                        for i, consumable in ipairs(G.consumeables.cards) do
                            table.insert(target_cards, consumable)
                        end
                        if #target_cards > 0 then
                            local card_to_destroy = pseudorandom_element(target_cards, pseudoseed('destroy_consumable'))
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    card_to_destroy:start_dissolve()
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Chomp!", colour = G.C.RED})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.chipvar = (card.ability.extra.chipvar) + card.ability.extra.incvar
                            return true
                        end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                                card.ability.extra.emptyvar = 0
                                return true
                            end,
                            colour = G.C.BLUE
                        }
                    }
                }
            elseif (to_big(#G.consumeables.cards) == to_big(0) and to_big((card.ability.extra.emptyvar or 0)) ~= to_big(2)) then
                return {
                    func = function()
                        card.ability.extra.emptyvar = (card.ability.extra.emptyvar) + 1
                        return true
                    end,
                    message = "Growl..."
                }
            elseif (to_big(#G.consumeables.cards) == to_big(0) and to_big((card.ability.extra.emptyvar or 0)) == to_big(2)) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            if target_joker.ability.eternal then
                                target_joker.ability.eternal = nil
                            end
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            
                            local created_joker = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_nx_3rendang' })
                                    if joker_card then
                                        
                                        
                                    end
                                    
                                    return true
                                end
                            }))
                            
                            if created_joker then
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Dead!", colour = G.C.BLUE})
                            end
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                x_chips = card.ability.extra.chipvar
            }
        end
    end
}